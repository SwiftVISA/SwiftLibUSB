//
//  main.swift
//  ExampleSwiftLibUSB
//
//  Created by Owen Hildreth on 12/2/22.
//

import Foundation
import SwiftLibUSB

print("Starting Example")

// You need to set the vendor and product ID to match your instrument's vendor and product ID
// THese are set for a Keysight E36103B power supply
let vendorID = 10893
let productID = 5634

// variables to hold the instrument manager and instrument
var instrumentManager: InstrumentManager?
var instrument: MessageBasedInstrument?


/// Function used  to make an instrument using the supplied IP address and port
func makeInstrument() throws {
    if instrumentManager == nil {
        instrumentManager = InstrumentManager.shared
    }
    
    instrument = try instrumentManager?.instrumentAt(vendorID: vendorID, productID: productID)
    
}

/// Connect to the instrument by making the instrument and then calling `updateMeasuredValue()` and `getInfo()` to print out the current voltage the power supply is set at and the power supply's information.
func connect() {
    do {
        try makeInstrument()
    } catch  {
        print("Could not connect to instrument with vendor ID: \(vendorID) and product ID: \(productID)")
        print(error)
    }
    
    print("instrument connected: \(String(describing: instrument))")
    updateMeasuredVoltage()
    getInfo()
}

func getInfo() {
    do {
        let localDetails = try instrument?.query("*IDN?") ?? ""
        let details = localDetails.replacingOccurrences(of: ",", with: "\n")
        print("Instrument Details:\n\(details)")
    } catch  {
        print("Could not get instrument information")
        print(error)
    }
}

func updateMeasuredVoltage() {
    do {
        let measuredVoltage = try instrument?.query("SOURCE:VOLTAGE?", as: Double.self)
        print("Measured voltage = \(String(describing: measuredVoltage))")
    } catch {
        print("Could not measure voltage")
        print(error)
    }
}


connect()

